package com.baloot.exception;

public class InValidInputException  extends  Exception{
    public InValidInputException(String message) {
        super(message);
    }
}
