package com.baloot.exception;

public class NotEnoughCreditException extends Exception{
    public NotEnoughCreditException() {
        super("Not Enough Credit");
        }

}
