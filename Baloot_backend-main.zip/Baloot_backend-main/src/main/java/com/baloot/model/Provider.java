package com.baloot.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "provider")
public class Provider {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name", length = 100)
    private String name;

    @Column(name = "registry_date")
    private String registryDate;

    @Column(name = "image", length = 100000)
    private String image;

    @Column(name = "rating", columnDefinition = "DECIMAL(10,2) DEFAULT '0.00'")
    private double rating;

    //@OneToMany(mappedBy = "provider", cascade = CascadeType.ALL)
    //private List<Commodity> commodities = new ArrayList<>();


    public Provider() {}

    public Provider(int id, String name, String registryDate) {
        this.id = id;
        this.name = name;
        this.registryDate = registryDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String nameE) {
        this.name = name;
    }

    public String getRegistryDate() {
        return registryDate;
    }

    public void setRegistryDate(String registryDate) {
        this.registryDate = registryDate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public List<Commodity> getCommodities() {
        //return commodities;
        return null;
    }

    public void setCommodities(List<Commodity> commodities) {
        //this.commodities = commodities;
    }

    public void addNewCommodity(Commodity newCommodity) {
        //newCommodity.setProvider(this);
        //commodities.add(newCommodity);
        calRating();
    }

    public void calRating() {
        double sum = 0;
        //for (Commodity commodity : commodities) {
        //    sum += commodity.getRating();
        //}
        //rating = sum / commodities.size();
    }
}
