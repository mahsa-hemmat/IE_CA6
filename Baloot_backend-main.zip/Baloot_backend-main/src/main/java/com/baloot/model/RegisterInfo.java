package com.baloot.model;

public class RegisterInfo {
    private String username;
    private String password;
    private String email;
    private String birthDate;
    private String address;
    public RegisterInfo(){}
    public String getUsername(){
        return username;
    }
    public String getPassword() {
        return password;
    }
    public String getEmail() {
        return email;
    }
    public String getBirthDate() {
        return birthDate;
    }
    public String getAddress() {
        return address;
    }
}
