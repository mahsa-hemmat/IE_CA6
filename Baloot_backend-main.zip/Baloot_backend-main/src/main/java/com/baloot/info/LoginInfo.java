package com.baloot.info;

public class LoginInfo {
    private String username;
    private String password;
    public LoginInfo(){}
    public String getUsername() {
        return username;
    }
    public String getPassword() { return password; }
}
