package com.baloot.info;

public class CartCommodityRequest {
    private int commodityId;
    private int quantity;

    public int getCommodityId() {
        return commodityId;
    }

    public int getQuantity() {
        return quantity;
    }
}
